# Pure CSS multilevel dropdown menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/SurajVerma/pen/wBMbqL](https://codepen.io/SurajVerma/pen/wBMbqL).

This is a minimal pure css multilevel dropdown menu. :)